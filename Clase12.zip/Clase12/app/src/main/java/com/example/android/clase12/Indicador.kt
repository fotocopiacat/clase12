package com.example.android.clase12

class Indicador (var codigo:String, var serie:ArrayList<Serie>) {
}