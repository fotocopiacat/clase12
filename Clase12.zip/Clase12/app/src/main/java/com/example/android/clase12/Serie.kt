package com.example.android.clase12

class Serie (var fecha : String, var valor:Float) {
}